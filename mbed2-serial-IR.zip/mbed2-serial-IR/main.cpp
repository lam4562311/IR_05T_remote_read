#include "mbed.h"
#include "SoftSerial.h"
#include "BufferedSerial.h"

#include "string"

BufferedSerial pc (USBTX, USBRX, 256);
BufferedSerial IR_05T_01 (D8, D2, 256);
BufferedSerial IR_05T_02 (PA_11, PA_12, 256);
SoftSerial IR_03T_01 (D3, D4);
//IR_03T_01.attach(callback(IR_03T_01, &BufferedSerial::rxIrq), Serial::RxIrq);
SoftSerial IR_03T_02 (D5, D6);

const uint8_t button_1[] = {0x01, 0x11, 0x11, 0x11, 0x12, 0x22, 0x22, 0x22, 0x21, 0x12, 0x21, 0x11, 0x12, 0x21, 0x12, 0x22, 0x23, 0x45};
const uint8_t button_2[] = {0x01, 0x11, 0x11, 0x11, 0x12, 0x22, 0x22, 0x22, 0x21, 0x11, 0x22, 0x11, 0x12, 0x22, 0x11, 0x22, 0x23, 0x45};
const uint8_t button_3[] = {0x01, 0x11, 0x11, 0x11, 0x12, 0x22, 0x22, 0x22, 0x21, 0x22, 0x22, 0x12, 0x12, 0x11, 0x11, 0x21, 0x23, 0x45};
const uint8_t button_4[] = {0x01, 0x11, 0x11, 0x11, 0x12, 0x22, 0x22, 0x22, 0x21, 0x11, 0x21, 0x11, 0x12, 0x22, 0x12, 0x22, 0x23, 0x45};
const uint8_t button_logo[] = {0x01, 0x11, 0x11, 0x11, 0x12, 0x22, 0x22, 0x22, 0x22, 0x12, 0x12, 0x11, 0x11, 0x21, 0x21, 0x22, 0x23, 0x45};


const uint8_t channel = 0x01;
const uint8_t IR_05T_learn_init[] = {0xFD, 0xFD, 0xF1, 0xF2, 0xDF};
uint8_t read_buffer[256] = {0x00};
//////////////IR_03T
uint8_t IR_03T_learn_init[] = {0xFA, 0xFD, 0x01, channel, 0xDF}; //->A1, success A2;
uint8_t IR_03T_read_data[] = {0xFA, 0xFD, 0x06, channel, 0xDF};
//////////////


bool available_learn_flag1 = true;
bool available_learn_flag2 = true;
bool available_learn_flag3 = true;
bool available_learn_flag4 = true;

string ans = "";


//void SoftSerial::saveing(void)
//{
//    // read from the peripheral and make sure something is available
//    if(readable()) {
//        _rxbuf = getc(); // if so load them into a buffer
//    }
//    return;
//}

void find_command(uint8_t * data){
  if (data[40] == 0x01) {
    
    if (memcmp(&data[40], button_1, 18) == 0)
      ans = "button_1";
    else if (memcmp(&data[40], button_2, 18) == 0)
      ans = "button_2";
    else if (memcmp(&data[40], button_3, 18) == 0)
      ans = "button_3";
    else if (memcmp(&data[40], button_4, 18) == 0)
      ans = "button_4";
    else if (memcmp(&data[40], button_logo, 18) == 0)
      ans = "button_logo";
    else
      ans = "invalid";
    pc.printf(ans.c_str());
  }
  else
    ans = "Error";
  
}

uint8_t* IR_05T_read_button(BufferedSerial &chip, bool &flag){
  if (chip.readable()){
      if (chip.getc() == 0xFD) {
        flag = true;
        read_buffer[0] = 0xFD;
        for (size_t i = 1 ; i < 236-1; i++){
            while (!chip.readable()){;}
            read_buffer[i] = chip.getc();
            }
            
//        for (size_t i = 0; i < 256; i++) {
//            pc.putc(read_buffer[i]);
//        }
         
        return read_buffer;
      }
  }
  return NULL;
}

void IR_05T_write_learn_state(BufferedSerial &chip, bool &flag){
  if (flag == true && chip.writeable()){
    chip.write(IR_05T_learn_init, 5);
    flag = false;
  }
}

uint8_t* soft_IR_03T_read_button(SoftSerial &chip, bool &flag){
//  chip.flush();


  chip.write(IR_03T_read_data, 5);
  
  while (!chip.readable()){;}
  
  pc.printf("Hello\n");
    flag = true;
    for (size_t i = 0 ; i < 236-1; i++){
        while (!chip.readable()){;}
        read_buffer[i] = chip.getc();
        }
        
        for (size_t i = 0; i < 256; i++) {
            pc.putc(read_buffer[i]);
        }
       pc.printf("====================================================out=====");   
    return read_buffer;
  // }
  return NULL;
}

void soft_IR_03T_write_learn_state(SoftSerial &chip, bool &flag){
  if (flag == true && chip.writeable()){
    chip.write(IR_03T_learn_init, 5);
    flag = false;
  }
}
int main() {
    
    
    while(1) {
        wait_ms(100);
        pc.printf("Hello World!\n");
      IR_05T_write_learn_state(IR_05T_01, available_learn_flag1);
      IR_05T_write_learn_state(IR_05T_02, available_learn_flag2);
      soft_IR_03T_write_learn_state(IR_03T_01, available_learn_flag3);
      
      if (IR_05T_01.readable()) {
        find_command(IR_05T_read_button(IR_05T_01, available_learn_flag1));
      }
      if (IR_05T_02.readable()) {
        find_command(IR_05T_read_button(IR_05T_02, available_learn_flag2));
      }   
      if (IR_03T_01.readable()){
        if (IR_03T_01.getc() == 0xA2) {
           pc.printf("check");
          wait_ms(100);     //delay required
          find_command(soft_IR_03T_read_button(IR_03T_01, available_learn_flag3));
        }
      }
    }
}