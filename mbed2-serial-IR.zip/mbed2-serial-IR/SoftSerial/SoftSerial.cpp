#include "SoftSerial.h"
#include <stdio.h>
#include <string.h>
#include <cstdarg>

SoftSerial::SoftSerial(PinName TX, PinName RX, const char* name) {
    tx_en = rx_en = false;
    read_buffer = 0;
    if (TX != NC) {
        tx = new DigitalOut(TX);
        tx_en = true;
        tx->write(1);
        tx_bit = -1;
    }
    if (RX != NC) {
        rx = new InterruptIn(RX, PullUp);
        rx_en = true;
        out_valid = false;
        rx->fall(this, &SoftSerial::rx_gpio_irq_handler);
    }

    baud(9600);
    format();
}

SoftSerial::~SoftSerial() {
    if (tx_en)
        delete(tx);
    if (rx_en)
        delete(rx);
}

void SoftSerial::baud(int baudrate) {
    bit_period = 1000000 / baudrate;
}

void SoftSerial::format(int bits, Parity parity, int stop_bits) {
    _bits = bits;
    _parity = parity;
    _stop_bits = stop_bits;
    _total_bits = 1 + _bits + _stop_bits + (bool)_parity;
}

ssize_t SoftSerial::write(const void *buffer, size_t length)
{
    const char *ptr = (const char *)buffer;
    const char *end = ptr + length;

    lock();
    while (ptr != end) {
        if (_putc(*ptr++) == EOF) {
            break;
        }
    }
    unlock();

    return ptr - (const char *)buffer;
}

int SoftSerial::puts(const char *s)
{
    const char* ptr = s;
    lock();
    while (*ptr != '\0') {
        if (_putc(*ptr++) == EOF) {
            break;
        }
    }
    unlock();

    return ptr - (const char *)s;
}

int SoftSerial::printf(const char *format, ...)
{
    std::va_list args;
    va_start(args, format);

    char dummy_buf[1];
    int len = vsnprintf(dummy_buf, sizeof(dummy_buf), format, args);
    char *temp = new char[len + 1];
    vsprintf(temp, format, args);
    write((const void*)temp, len);
    delete[] temp;

    va_end(args);
    return len;
}
    


