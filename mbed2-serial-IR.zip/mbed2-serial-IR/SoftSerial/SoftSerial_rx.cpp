#include "SoftSerial.h"

uint32_t overhead_us = 200 * 1000000 / SystemCoreClock;         //Random estimation of the overhead of mbed libs, makes slow devices like LPC812 @ 12MHz perform better

DigitalOut debugPin(D7, 1);
extern Serial hws2;

int SoftSerial::_getc( void ) {
    while(!readable());
    out_valid = false;
    return out_buffer;
}

int SoftSerial::readable(void) {
    return out_valid;
}

//Start receiving byte
void SoftSerial::rx_gpio_irq_handler(void) {
    int start = us_ticker_read();
    rx->disable_irq();
    
    out_valid = false;
    read_buffer = 0;
    rx_bit = 0;
    rx_error = false;

    debugPin = 0;
    wait_us(5);
    debugPin = 1;
    int end = us_ticker_read();

    wait_us(bit_period + (bit_period / 2) - (end - start) - 15);

    rx_handler();   
};

void SoftSerial::rx_handler(void) {

    int start, end = 0;
    int val = 0;
    for (rx_bit = 0; rx_bit < _bits; ++rx_bit) {
        start = us_ticker_read();
        val = rx->read();
#if DEBUG
        debugPin = 0;
        wait_us(5);
        debugPin = 1;
#endif
        read_buffer |= ((0x0001 & val) << rx_bit);
        int end = us_ticker_read();

        wait_us(bit_period - (end - start));
    }

    // Check SUM
    if (_parity != None) {
        start = us_ticker_read();
        int val = rx->read();
#if DEBUG
        debugPin = 0;
        wait_us(5);
        debugPin = 1;
#endif
        int end = us_ticker_read();
        wait_us(bit_period - (end - start));
        
        bool parity_count = 0;
        switch (_parity) {
            case Forced1:
                if (val == 0)
                    rx_error = true;
                break;
            case Forced0:
                if (val == 1)
                    rx_error = true;
                break;
            case Even:
            case Odd:
                parity_count = val;
                for (int i = 0; i<_bits; i++) {
                    if (((read_buffer >> i) & 0x01) == 1)
                        parity_count = !parity_count;
                }
                if ((parity_count) && (_parity == Even))
                    rx_error = true;
                if ((!parity_count) && (_parity == Odd))
                    rx_error = true;
                break;
            case None:
            default:
                break;
        }
    }
    // Stop Bit
    start = us_ticker_read();
    int stopBit = rx->read();
#if _DEBUG
    debugPin = 0;
    wait_us(5);
    debugPin = 1;
    end = us_ticker_read();
//    wait_us((bit_period / 2) - (end - start) + 15);
#endif

    if (stopBit == 1 && rx_error == false) {
        out_valid = true;
        out_buffer = read_buffer;
        fpointer[RxIrq].call();
    } else {
        out_valid = false;
        out_buffer = 0;
        rx_error = true;
    }

    rx->enable_irq();
    
#if 0
    debugPin = 0;
    rx_error = false;
    rxticker.prime();

    //Receive data
    int val = rx->read();
    wait_us(1);
    int val2 = rx->read();
    wait_us(1);
    int val3 = rx->read();

    while(1) {
        if (val == val2 && val == val3) {   
        } else {
            rx_error = true;
            break;
        }
    
        rx_bit++;
        
        if (rx_bit <= _bits) {
            read_buffer |= val << (rx_bit - 1);
            break;
        }
        
        //Receive parity
        bool parity_count;
        if (rx_bit == _bits + 1) {
            switch (_parity) {
                case Forced1:
                    if (val == 0)
                        rx_error = true;
                    break;
                case Forced0:
                    if (val == 1)
                        rx_error = true;
                    break;
                case Even:
                case Odd:
                    parity_count = val;
                    for (int i = 0; i<_bits; i++) {
                        if (((read_buffer >> i) & 0x01) == 1)
                            parity_count = !parity_count;
                    }
                    if ((parity_count) && (_parity == Even))
                        rx_error = true;
                    if ((!parity_count) && (_parity == Odd))
                        rx_error = true;
                    break;
            }
        }
        
        //Receive stop
        if (rx_bit < _bits + (bool)_parity + _stop_bits) {
            if (!val)
                rx_error = true;
            break;
        }
        
        //The last stop bit
        if (!val)
            rx_error = true;
        
        if (!rx_error) {
            out_valid = true;
            out_buffer = read_buffer;
            fpointer[RxIrq].call();
            break;
        }
        read_buffer = 0;
        rxticker.detach();
        rx->fall(this, &SoftSerial::rx_gpio_irq_handler);
        
        break;
    }
    
    if (rx_error) {
        read_buffer = 0;
        rxticker.detach();
        rx->fall(this, &SoftSerial::rx_gpio_irq_handler);
    } else {
        rxticker.setNext(bit_period);
    }

    debugPin = 1;
#endif
}

