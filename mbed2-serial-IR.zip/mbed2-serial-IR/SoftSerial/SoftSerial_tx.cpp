#include "mbed.h"
#include "SoftSerial.h"

int SoftSerial::_putc(int c)
{
    while(!writeable());
    prepare_tx(c);
    tx_bit = 0;
    tx_handler();
    
    return 0;
}

void SoftSerial::send_break(void) {
    while(!writeable());
    tx_bit = 0;         //Just to make sure it appears as non-writable to other threads/IRQs
    tx->write(0);
    wait_us((bit_period * _total_bits * 3) / 2);
    tx->write(1);
    tx_bit = -1;
}

int SoftSerial::writeable(void)
{
    if (!tx_en)
        return false;
    if (tx_bit == -1)
        return true;
    return false;
}

void SoftSerial::tx_handler(void)
{
    for (tx_bit = 0; tx_bit < _total_bits; ++tx_bit) {
        tx->write(0x0001 & (_char >> tx_bit));
        wait_us(bit_period);
    }
    tx_bit = -1;
    tx->write(1);
    fpointer[TxIrq].call();
}

void SoftSerial::prepare_tx(int c)
{
    // Insert start bit.
    _char = c << 1;

    bool parity;
    switch (_parity) {
        case Forced1:
            _char |= 1 << (_bits + 1);
        case Even:
            parity = false;
            for (int i = 0; i<_bits; i++) {
                if (((_char >> i) & 0x01) == 1)
                    parity = !parity;
            }
            _char |= parity << (_bits + 1);
        case Odd:
            parity = true;
            for (int i = 0; i<_bits; i++) {
                if (((_char >> i) & 0x01) == 1)
                    parity = !parity;
            }
            _char |= parity << (_bits + 1);
    }
    
    // Insert stop bits.
    _char |= 0xFFFF << (1 + _bits + (bool)_parity);

}
