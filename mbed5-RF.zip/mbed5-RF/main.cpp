/* mbed Microcontroller Library
 * Copyright (c) 2019 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

#include "mbed.h"
#include "platform/mbed_thread.h"

#include "string"

Thread t;

// Blinking rate in milliseconds

#define BLINKING_RATE_MS                                                    500

InterruptIn Input1(D7,PullDown);
InterruptIn Input2(D6,PullDown);
InterruptIn Input3(D5,PullDown);
InterruptIn Input4(D4,PullDown);

DigitalOut led1(LED1);

EventQueue queue(32 * EVENTS_EVENT_SIZE);

string data = "jellp";
char button1[] = "button_1";
char button2[] = "button_2";
char button3[] = "button_3";
char button4[] = "button_4";

void handler_user_context(string asd) {
    printf("%s\n", asd.c_str());
}
void handler_user_context_in_char(char* asd) {
    printf("%s\n", asd);
}
void rise_handler(string data) {
    queue.call(handler_user_context, data);
}
void fall_handler(char* data) {
    queue.call(handler_user_context_in_char, data);
}

int main()
{
    Input1.fall(queue.event(fall_handler, button1));
    Input2.fall(queue.event(fall_handler, button2));
    Input3.fall(queue.event(fall_handler, button3));
    Input4.fall(queue.event(fall_handler, button4));
    
    t.start(callback(&queue, &EventQueue::dispatch_forever));
}
